<?php

namespace App\Http\Controllers;

use App\Category;
use App\Panel;
use App\Http\Resources\PanelResource;
class CategoriesController extends Controller {
}
