<!DOCTYPE html>
<html lang="en">

<head>
    <!-- <meta charset="UTF-8"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <title><?php echo e($selectedCategory->name); ?> CheatSheet</title>
    <link rel="shortcut icon" href="<?php echo e($selectedCategory->image_url); ?>" type="image/x-icon">
</head>

<body>
    <nav class="nav">
        <div class="container">
            <div class="row justify-content-between">
                <div class="brand"><img class="img-fluid" width="250px" src="<?php echo e(asset('images/brand.png')); ?>" alt="">
                </div>
                <div class="menu-toggle my-auto" onclick="toggleDrawer();">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <div class="navigation-drawer" onclick="toggleDrawer()"></div>

    <div class="collapsed-menu">
        <div onclick="toggleDrawer()" class="closeButton">
            <a>X</a>
        </div>
        <div class="menu-container">
            <ul class="list-unstyled">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><img class="img-fluid" width="40px" height="40px" src="<?php echo e($category->image_url); ?>">

                    <?php if(Route::currentRouteName()==='admin.index'||Route::currentRouteName()==='admin.show'): ?>
                    <a href="<?php echo e(route('admin.show',['categoryTitle'=>$category->name])); ?>"><?php echo e($category->name); ?></a>

                    <a id="edit" data-toggle="modal" data-target="#modal" data-category_id="<?php echo e($category->id); ?>"
                        data-category_name="<?php echo e($category->name); ?>"
                        data-category_image="<?php echo e($category->getAttributes()['image_url']); ?>"><i
                            class="fas fa-edit"></i></a>
                    <a id="delete" href="<?php echo e(route('categories.delete',['id'=>$category->id])); ?>">x</a>
                    <?php endif; ?>


                    <?php if(Route::currentRouteName()==='guest.index'||Route::currentRouteName()==='guest.show'): ?>
                    <a href="<?php echo e(route('guest.show',['categoryTitle'=>$category->name])); ?>"><?php echo e($category->name); ?></a>
                    <?php endif; ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php if(Route::currentRouteName()==='admin.index'||Route::currentRouteName()==='admin.show'): ?>
            <form id="new-category" action="<?php echo e(route('categories.create')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input placeholder="New Category" id="category_name" name="name" type="text" class="form-control">
                </div>
            </form>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary d-block mx-auto">Logout</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if(auth()->guard()->check()): ?>
    <!-- Modal -->
    <div class="modal fade" id="modal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white rounded-0">
                    <h5 class="modal-title" id="title">Edit Category</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="edit_form" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <input id="category" name="name" type="text" class="form-control">
                        <input id="image" name="image" type="text" class="form-control">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary"
                        onclick="event.preventDefault(); document.getElementById('edit_form').submit();">Save</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <main id="app">
        <div class="loader" ref="loadingContainer"></div>
        <?php if(Route::currentRouteName()==='admin.index'||Route::currentRouteName()==='admin.show'): ?>
        <all_panels_in_admin :category="<?php echo e($selectedCategory); ?>"></all_panels_in_admin>
        <?php endif; ?>

        <?php if(Route::currentRouteName()==='guest.index'||Route::currentRouteName()==='guest.show'): ?>
        <all_panels_in_home :category="<?php echo e($selectedCategory); ?>"></all_panels_in_home>
        <?php endif; ?>

    </main>

    <script src=<?php echo e(asset( 'js/app.js')); ?>></script>
    <script>
       
        function toggleDrawer() {
            $('.collapsed-menu').toggleClass('show');
            $('.navigation-drawer').toggleClass('show');
        }

        $('#modal').on('show.bs.modal', function (event) {
            var hyperLink = $(event.relatedTarget); // Button that triggered the modal
            var category_id = hyperLink.data('category_id');
            var category_name = hyperLink.data('category_name');
            var image = hyperLink.data('category_image');
       
            var modal = $(this);
            modal.find('.modal-body input#category').val(category_name);
            modal.find('.modal-body input#image').val(image);
            modal.find('.modal-body #edit_form').attr("action",document.location.origin+"/admin/categories/edit/"+category_id);
        }); 
       
    </script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138512204-2"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-138512204-2');
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\devPath\resources\views/index.blade.php ENDPATH**/ ?>