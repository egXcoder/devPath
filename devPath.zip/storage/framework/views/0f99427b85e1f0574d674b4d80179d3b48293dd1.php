<?php $__env->startSection('all_panels'); ?>
<all_panels_in_admin :category="<?php echo e($selectedCategory); ?>"></all_panels_in_admin>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devPath\resources\views/admin.blade.php ENDPATH**/ ?>