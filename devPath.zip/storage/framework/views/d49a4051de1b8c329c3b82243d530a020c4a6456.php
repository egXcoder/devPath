 

<?php $__env->startSection('all_panels'); ?>
<all_panels_in_home></all_panels_in_home>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devPath\resources\views/home.blade.php ENDPATH**/ ?>